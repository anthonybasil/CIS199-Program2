﻿namespace Program2
{
    partial class Program2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.calcCost = new System.Windows.Forms.Button();
            this.results = new System.Windows.Forms.GroupBox();
            this.lowestCost = new System.Windows.Forms.Label();
            this.compCCostTotal = new System.Windows.Forms.Label();
            this.compBCostTotal = new System.Windows.Forms.Label();
            this.compACostTotal = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pkgWeight = new System.Windows.Forms.TextBox();
            this.distMiles = new System.Windows.Forms.TextBox();
            this.delDays = new System.Windows.Forms.TextBox();
            this.results.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(67, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Package Weight";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(67, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Distance (Miles)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(67, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Delivery Days";
            // 
            // calcCost
            // 
            this.calcCost.Location = new System.Drawing.Point(160, 107);
            this.calcCost.Name = "calcCost";
            this.calcCost.Size = new System.Drawing.Size(90, 23);
            this.calcCost.TabIndex = 6;
            this.calcCost.Text = "Calculate Cost";
            this.calcCost.UseVisualStyleBackColor = true;
            this.calcCost.Click += new System.EventHandler(this.calcCost_Click);
            // 
            // results
            // 
            this.results.Controls.Add(this.lowestCost);
            this.results.Controls.Add(this.compCCostTotal);
            this.results.Controls.Add(this.compBCostTotal);
            this.results.Controls.Add(this.compACostTotal);
            this.results.Controls.Add(this.label6);
            this.results.Controls.Add(this.label5);
            this.results.Controls.Add(this.label4);
            this.results.Location = new System.Drawing.Point(40, 149);
            this.results.Name = "results";
            this.results.Size = new System.Drawing.Size(255, 165);
            this.results.TabIndex = 7;
            this.results.TabStop = false;
            this.results.Text = "Results";
            // 
            // lowestCost
            // 
            this.lowestCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lowestCost.Location = new System.Drawing.Point(27, 118);
            this.lowestCost.Name = "lowestCost";
            this.lowestCost.Size = new System.Drawing.Size(188, 20);
            this.lowestCost.TabIndex = 11;
            // 
            // compCCostTotal
            // 
            this.compCCostTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.compCCostTotal.Location = new System.Drawing.Point(115, 76);
            this.compCCostTotal.Name = "compCCostTotal";
            this.compCCostTotal.Size = new System.Drawing.Size(100, 20);
            this.compCCostTotal.TabIndex = 10;
            // 
            // compBCostTotal
            // 
            this.compBCostTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.compBCostTotal.Location = new System.Drawing.Point(115, 52);
            this.compBCostTotal.Name = "compBCostTotal";
            this.compBCostTotal.Size = new System.Drawing.Size(100, 20);
            this.compBCostTotal.TabIndex = 9;
            // 
            // compACostTotal
            // 
            this.compACostTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.compACostTotal.Location = new System.Drawing.Point(115, 28);
            this.compACostTotal.Name = "compACostTotal";
            this.compACostTotal.Size = new System.Drawing.Size(100, 20);
            this.compACostTotal.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 83);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Company A Cost";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 59);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Company A Cost";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Company A Cost";
            // 
            // pkgWeight
            // 
            this.pkgWeight.Location = new System.Drawing.Point(160, 24);
            this.pkgWeight.Name = "pkgWeight";
            this.pkgWeight.Size = new System.Drawing.Size(100, 20);
            this.pkgWeight.TabIndex = 8;
            // 
            // distMiles
            // 
            this.distMiles.Location = new System.Drawing.Point(160, 51);
            this.distMiles.Name = "distMiles";
            this.distMiles.Size = new System.Drawing.Size(100, 20);
            this.distMiles.TabIndex = 9;
            // 
            // delDays
            // 
            this.delDays.Location = new System.Drawing.Point(160, 77);
            this.delDays.Name = "delDays";
            this.delDays.Size = new System.Drawing.Size(100, 20);
            this.delDays.TabIndex = 10;
            // 
            // Program2
            // 
            this.AcceptButton = this.calcCost;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(334, 361);
            this.Controls.Add(this.delDays);
            this.Controls.Add(this.distMiles);
            this.Controls.Add(this.pkgWeight);
            this.Controls.Add(this.results);
            this.Controls.Add(this.calcCost);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Program2";
            this.Text = "Program2";
            this.results.ResumeLayout(false);
            this.results.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button calcCost;
        private System.Windows.Forms.GroupBox results;
        private System.Windows.Forms.Label lowestCost;
        private System.Windows.Forms.Label compCCostTotal;
        private System.Windows.Forms.Label compBCostTotal;
        private System.Windows.Forms.Label compACostTotal;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox pkgWeight;
        private System.Windows.Forms.TextBox distMiles;
        private System.Windows.Forms.TextBox delDays;
    }
}

