﻿// Grading ID: 
// Program 2
// 10-15-20
// CIS 199-01
// This program takes inputs (package weight, distance, and delivery days)
// and calculates the shipping cost for three different companies, then
// determines the company with the lowest cost.


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Console;

namespace Program2
{
    public partial class Program2 : Form
    {

        //define variables

        double weight;
        double distance;
        int days;

        double compACost;
        double compBCost;
        double compCCost;

        // comp A variables

        const double compAMiles = .02;
        const int compADelOne = 20;
        const int compADelTwo = 17;
        const int compADelThree = 15;
        const int compADelFour = 10;
        const int compADelFive = 7;
        const int compADelOneCost = 1;
        const int compADelTwoCost = 2;
        const int compADelThreeCost = 3;
        const int compADelFourCost = 4;
        const int compADelFiveCost = 7;

        // comp B Variables

        const double compBMiles = .10;
        const double compBWeightOne = .15;
        const int compBWeightTwo = 20;
        const int compBWeightThree = 10;
        const int compBWeightFour = 5;
        const int compBWeightFive = 3;
        const int compBDelLong = 7;
        const int compBDelShort = 10;
        const int compBWeightOneCost = 200;
        const int compBWeightTwoCost = 100;
        const int compBWeightThreeCost = 50;
        const int compBWeightFourCost = 10;
        const int compBDelLength = 4;

        // comp C variables

        const double compCWeight = .25;
        const int compCDel = 20;
        const int compCDisOne = 40;
        const int compCDisTwo = 35;
        const int compCDisThree = 25;
        const int compCDisFour = 15;
        const int compCDisFive = 10;
        const int compCDisOneCost = 1000;
        const int compCDisTwoCost = 750;
        const int compCDisThreeCost = 500;
        const int compCDisFourCost = 200;

        public Program2()
        {
            InitializeComponent();
        }

        // event handler for cost button
        private void calcCost_Click(object sender, EventArgs e)
        {

            // starts if statements

            if (double.TryParse(pkgWeight.Text, out weight))
            {
                if (double.TryParse(distMiles.Text, out distance))
                {
                    if (int.TryParse(delDays.Text, out days))
                    {

                        // comp A calculations

                        if (days == compADelOneCost)
                            compACost = weight + compAMiles * distance + compADelOne;
                        else if (days == compADelTwoCost)
                            compACost = weight + compAMiles * distance + compADelTwo;
                        else if (days == compADelThreeCost)
                            compACost = weight + compAMiles * distance + compADelThree;
                        else if (days >= compADelFourCost && days <= compADelFiveCost)
                            compACost = weight + compAMiles * distance + compADelFour;
                        else
                            compACost = weight + compAMiles * distance + compADelFive;

                        // comp B calculations

                        if (weight >= compBWeightOneCost && days > compBDelLength)
                            compBCost = compBWeightOne * weight + compBMiles * distance + compBDelLong;
                        else if (weight >= compBWeightOneCost && days <= compBDelLength)
                            compBCost = compBWeightOne * weight + compBMiles * distance + compBDelShort;
                        else if (weight >= compBWeightTwoCost && days > compBDelLength)
                            compBCost = compBWeightTwo + compBMiles * distance + compBDelLong;
                        else if (weight >= compBWeightTwoCost && days <= compBDelLength)
                            compBCost = compBWeightTwo + compBMiles * distance + compBDelShort;
                        else if (weight >= compBWeightThreeCost && days > compBDelLength)
                            compBCost = compBWeightThree + compBMiles * distance + compBDelLong;
                        else if (weight >= compBWeightThreeCost && days <= compBDelLength)
                            compBCost = compBWeightThree + compBMiles * distance + compBDelShort;
                        else if (weight >= compBWeightFourCost && days > compBDelLength)
                            compBCost = compBWeightFour + compBMiles * distance + compBDelLong;
                        else if (weight >= compBWeightFourCost && days <= compBDelLength)
                            compBCost = compBWeightFour + compBMiles * distance + compBDelShort;
                        else if (weight < compBWeightFourCost && days > compBDelLength)
                            compBCost = compBWeightFive + compBMiles * distance + compBDelLong;
                        else
                            compBCost = compBWeightFive + compBMiles * distance + compBDelShort;

                        // comp C calculations

                        if (distance >= compCDisOneCost)
                            compCCost = compCWeight * weight + compCDisOne + compCDel;
                        else if (distance >= compCDisTwoCost)
                            compCCost = compCWeight * weight + compCDisTwo + compCDel;
                        else if (distance >= compCDisThreeCost)
                            compCCost = compCWeight * weight + compCDisThree + compCDel;
                        else if (distance >= compCDisFourCost)
                            compCCost = compCWeight * weight + compCDisFour + compCDel;
                        else
                            compCCost = compCWeight * weight + compCDisFive + compCDel;

                        // input costs into labels

                        compACostTotal.Text = ($"{compACost:C2}");
                        compBCostTotal.Text = ($"{compBCost:C2}");
                        compCCostTotal.Text = ($"{compCCost:C2}");

                    }
                    else
                    {

                        // error messages

                        if (weight < 0)
                            MessageBox.Show("Invalid Weight.");
                        else if (distance < 0)
                            MessageBox.Show("Invalid Distance.");
                        else if (days < 0)
                            MessageBox.Show("Invalid Delivery Days.");


                    }

                    // input lowestest cost label

                    if (compACost < compBCost && compACost < compCCost)
                        lowestCost.Text = ("The lowest cost company is: A");
                    else if (compBCost < compACost && compBCost < compCCost)
                        lowestCost.Text = ("The lowest cost company is: B");
                    else
                        lowestCost.Text = ("The lowest cost company is: C");
                }
            }

        }
    }
}
